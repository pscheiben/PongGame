/*
 * ball_movement.h
 *
 *  Created on: 10 Nov 2017
 *      Author: mor2
 */

#ifndef BALL_MOVEMENT_H_
#define BALL_MOVEMENT_H_

void ball_update(void);

#endif /* BALL_MOVEMENT_H_ */
